
<div class="content-wrapper">
	
	<section class="content">
		<div class="box box-warning box-solid">
			<div class="box-header with-border">
				<h3 class="box-title">DETAIL DATA TBL_PEKERJAAN_BANJARMASIN</h3>
			</div>
		
		<table class='table table-bordered'>        

	
			<tr>
				<td>Id Sub Banjarmasin</td>
				<td><?php echo $id_sub_banjarmasin; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Stuf</td>
				<td><?php echo $tgl_stuf; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Selesai Stuf</td>
				<td><?php echo $tgl_selesai_stuf; ?></td>
			</tr>
	
			<tr>
				<td>Etd Kapal</td>
				<td><?php echo $etd_kapal; ?></td>
			</tr>
	
			<tr>
				<td>Eta Kapal</td>
				<td><?php echo $eta_kapal; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Mulai Doring</td>
				<td><?php echo $tgl_mulai_doring; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Selesai Doring</td>
				<td><?php echo $tgl_selesai_doring; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Bap</td>
				<td><?php echo $tgl_bap; ?></td>
			</tr>
	
			<tr>
				<td>Jumlah Dikerjakan</td>
				<td><?php echo $jumlah_dikerjakan; ?></td>
			</tr>
	
			<tr>
				<td>Sisa Belum</td>
				<td><?php echo $sisa_belum; ?></td>
			</tr>
	
			<tr>
				<td>Status</td>
				<td><?php echo $status; ?></td>
			</tr>
	
			<tr>
				<td>Keterangan</td>
				<td><?php echo $keterangan; ?></td>
			</tr>
	
			<tr>
				<td></td>
				<td><a href="<?php echo site_url('tbl_pekerjaan_banjarmasin') ?>" class="btn btn-default">Kembali</a></td>
			</tr>
	
		</table>
		</div>
	</section>
</div>