
<div class="content-wrapper">
	
	<section class="content">
		<div class="box box-warning box-solid">
			<div class="box-header with-border">
				<h3 class="box-title">DETAIL DATA TBL_WAITING_BANJARMASIN</h3>
			</div>
		
		<table class='table table-bordered'>        

	
			<tr>
				<td>Id Sub Banjarmasin</td>
				<td><?php echo $id_sub_banjarmasin; ?></td>
			</tr>
	
			<tr>
				<td>No Invoice</td>
				<td><?php echo $no_invoice; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Permintaan</td>
				<td><?php echo $tgl_permintaan; ?></td>
			</tr>
	
			<tr>
				<td>Deskripsi</td>
				<td><?php echo $deskripsi; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Persetujuan 1</td>
				<td><?php echo $tgl_persetujuan_1; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Persetujuan 2</td>
				<td><?php echo $tgl_persetujuan_2; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Pembatalan 1</td>
				<td><?php echo $tgl_pembatalan_1; ?></td>
			</tr>
	
			<tr>
				<td>Tgl Pembatalan 2</td>
				<td><?php echo $tgl_pembatalan_2; ?></td>
			</tr>
	
			<tr>
				<td>Acc</td>
				<td><?php echo $acc; ?></td>
			</tr>
	
			<tr>
				<td>Batal</td>
				<td><?php echo $batal; ?></td>
			</tr>
	
			<tr>
				<td></td>
				<td><a href="<?php echo site_url('tbl_waiting_banjarmasin') ?>" class="btn btn-default">Kembali</a></td>
			</tr>
	
		</table>
		</div>
	</section>
</div>